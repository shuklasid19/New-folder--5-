import pandas as pd
import numpy as np
from package.utility import *

data = "https://gist.githubusercontent.com/curran/a08a1080b88344b0c8a7/raw/0e7a9b0a5d22642a06d3d5b9bcbad9890c8ee534/iris.csv"

df = read_csv(data)

print(df)

mean_df = mean_val(df.mean())


print(df.describe())
