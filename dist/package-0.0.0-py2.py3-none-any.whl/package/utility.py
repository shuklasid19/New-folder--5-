import numpy as np
import pandas as pd

def read_csv(data):
    return pd.read_csv(data)

def mean_val(data):
    return data.mean()